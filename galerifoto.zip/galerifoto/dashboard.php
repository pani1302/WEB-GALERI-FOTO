<?php
    session_start();
	if($_SESSION['status_login'] != true){
		echo '<script>window.location="login.php"</script>';
    }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WEB Galeri Foto</title>
<link rel="stylesheet" type="text/css" href="css/sytle1.css">
</head>

<body>
    <!-- header -->
    <header class="b">
        <div class="container">
        <h1><a href="dashboard.php">WEB GALERI FOTO</a></h1>
        <ul>
           <li><a href="dashboard.php">Dashboard</a></li>
           <li><a href="profil.php">Profil</a></li>
           <li><a href="data-image.php">Data Foto</a></li>
           <li><a href="Keluar.php">Keluar</a></li>
        </ul>
        </div>
    </header>
    
    <!-- content -->
    <div class="section">
        <div class="container">
            <h3>Dashboard</h3>
            <div class="box">
                <h4>Selamat Datang <?php echo $_SESSION['a_global']->admin_name ?> di Website Galeri Foto</h4>
            </div>
        </div>
    </div>
    
    <!-- footer -->
    <footer>
        <div class="container">

        </div>
    </footer>
</body>
</html>



<?php
    include 'db.php';
    $kontak = mysqli_query($conn, "SELECT admin_telp, admin_email, admin_address FROM tb_admin WHERE admin_id = 2");
    $a = mysqli_fetch_object($kontak);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WEB Galeri Foto</title>
<link href="foto/foto1737443731.png" rel="shortcut icon" />
<link rel="stylesheet" type="text/css" href="css/style.css">
<style>
   .image-details {
    display: flex;
    justify-content: space-between; 
    align-items: flex-start;
}

.image-info {
    max-width: 90%; /* Menjaga info gambar agar tidak terlalu lebar */
}

.image-icons {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 5px;
    margin-left: auto; /* Memindahkan ikon ke kanan */
}

.image-icons span {
    display: flex;
    align-items: center;
    gap: 5px;
}

.category {
    font-size: 12px;
    font-weight: bold;
    color: #555;
    margin-bottom: 5px;
}

    .col-4{
        height: 300px;
        weight: 15px;
    }

    .b {
        background-color: #28a745
    color:rgb(248, 238, 238);
}
    
</style>
</head>

<body>
    <!-- header -->
    <header>
        <div class="container">
       
        <h3>Foto Terbaru</h3>
        </div>
    </header>
    
   
    <!-- new product -->
    <div class="container">
       <div class="box">
          <?php
              $foto = mysqli_query($conn, "SELECT * FROM tb_image 
                                           LEFT JOIN tb_category ON tb_image.category_id = tb_category.category_id 
                                           WHERE image_status = 1 
                                           ORDER BY image_id DESC 
                                           LIMIT 8");
              if(mysqli_num_rows($foto) > 0){
                  while($p = mysqli_fetch_array($foto)){
                      // Menghitung jumlah like untuk setiap gambar
                      $like_count = mysqli_query($conn, "SELECT COUNT(*) AS total_likes FROM tb_likes WHERE image_id = '".$p['image_id']."'");
                      $like_count = mysqli_fetch_assoc($like_count)['total_likes'];

                      // Menghitung jumlah komentar untuk setiap gambar
                      $comment_count = mysqli_query($conn, "SELECT COUNT(*) AS total_comments FROM tb_comments WHERE image_id = '".$p['image_id']."'");
                      $comment_count = mysqli_fetch_assoc($comment_count)['total_comments'];
          ?>
          <a href="detail-image-dashboard.php?id=<?php echo $p['image_id'] ?>">
          <div class="col-4">
              <!-- Gambar Foto -->
              <div class="image-container">
                  <img src="foto/<?php echo $p['image'] ?>" height="150px" />
              </div>
              <!-- Detail Foto -->
              <div class="image-details">
                  <div class="image-info">
                      <!-- Kategori Foto -->
                      <p class="category">Kategori: <?php echo $p['category_name'] ?></p>
                      <p class="admin">Nama User : <?php echo $p['admin_name'] ?></p>
                      <p class="nama"><?php echo $p['date_created'] ?></p>
                  </div>
                  <div class="image-icons">
                      <span>
                          ❤️ <?php echo $like_count ?>
                      </span>
                      <span>
                          💬 <?php echo $comment_count ?>
                      </span>
                  </div>
              </div>
          </div>
          </a>
          <?php }}else{ ?>
              <p>Foto tidak ada</p>
          <?php } ?>
       </div>
    </div>
    
    <!-- footer -->
     <footer>
        <div class="container">
            <small>Copyright &copy; 2024 - Web Galeri Foto.</small>
        </div>
    </footer>
</body>
</html>









