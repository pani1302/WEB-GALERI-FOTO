<?php
session_start();
include 'db.php';

if (!isset($_SESSION['status_login'])) {
    echo '<script>alert("Anda harus login untuk memberikan Like."); window.location="login.php";</script>';
    exit;
}

if (isset($_POST['like'])) {
    $image_id = $_POST['image_id'];
    $user_id = $_SESSION['id'];

    // Periksa apakah pengguna sudah memberikan Like
    $check_like = mysqli_query($conn, "SELECT * FROM likes WHERE user_id = '$user_id' AND image_id = '$image_id'");
    if (mysqli_num_rows($check_like) == 0) {
        // Jika belum, tambahkan Like
        mysqli_query($conn, "INSERT INTO likes (user_id, image_id) VALUES ('$user_id', '$image_id')");
    }

    echo '<script>window.location="index.php";</script>';
}
?>
