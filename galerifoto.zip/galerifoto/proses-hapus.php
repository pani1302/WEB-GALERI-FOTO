<?php
   include 'db.php';
   
   if (isset($_GET['idp'])) {
       // Ambil data gambar berdasarkan image_id
       $foto = mysqli_query($conn, "SELECT image FROM tb_image WHERE image_id = '".$_GET['idp']."' ");
       
       if (mysqli_num_rows($foto) > 0) {
           $p = mysqli_fetch_object($foto);
       } else {
           echo "<script>alert('Gambar tidak ditemukan!'); window.location='data-image.php';</script>";
           exit;
       }

       // Pastikan file gambar ada di direktori
       if (file_exists('./foto/' . $p->image)) {
           if (!unlink('./foto/' . $p->image)) {
               echo "<script>alert('Gagal menghapus file gambar.'); window.location='data-image.php';</script>";
               exit;
           }
       } else {
           echo "<script>alert('File gambar tidak ditemukan!'); window.location='data-image.php';</script>";
           exit;
       }

       // Hapus data gambar dari database
       $delete = mysqli_query($conn, "DELETE FROM tb_image WHERE image_id = '".$_GET['idp']."' ");
       if ($delete) {
           echo '<script>window.location="data-image.php"</script>';
       } else {
           echo "<script>alert('Gagal menghapus data dari database!'); window.location='data-image.php';</script>";
       }
   } else {
       echo "<script>alert('ID tidak ditemukan!'); window.location='data-image.php';</script>";
       exit;
   }
?>
