<?php
    include 'db.php';
    $kontak = mysqli_query($conn, "SELECT admin_telp, admin_email, admin_address FROM tb_admin WHERE admin_id = 2");
    $a = mysqli_fetch_object($kontak);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Galeri Foto</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<!-- Menambahkan Font Awesome CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
    .image-details {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
    }
    .image-info {
        max-width: 90%;
    }
    .image-icons {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 5px;
    }
    .image-icons span {
        display: flex;
        align-items: center;
        gap: 5px;
    }
    .category {
        font-size: 12px;
        font-weight: bold;
        color: #555;
        margin-bottom: 5px;
    }
    .col-4 img {
    width: 100% !important;
    height: 150px !important;
    object-fit: cover !important;
    border-radius: 6px !important;
}
  
</style>
</head>

<body>
    <!-- header -->
    <header>
    <div class="container">
        <h1><a href="index.php">GALERI FOTO</a></h1>
        <nav>
            <ul class="menu">
                <li><a href="galeri.php">Galeri</a></li>
                <li><a href="registrasi.php">Registrasi</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </nav>
    </div>
</header>

    
    <!-- search -->
    <div class="search">
        <div class="container">
            <form action="galeri.php">
                <input type="text" name="search" placeholder="Cari Foto" />
                <input type="submit" name="cari" value="Cari Foto" />
            </form>
        </div>
    </div>
    
    <!-- category -->
    <div class="section">
        <div class="container">
            <h3>Kategori</h3>
        
                <?php
                    $kategori = mysqli_query($conn, "SELECT * FROM tb_category ORDER BY category_id DESC");
                    if(mysqli_num_rows($kategori) > 0){
                        while($k = mysqli_fetch_array($kategori)){
                ?>
                    <a href="galeri.php?kat=<?php echo $k['category_id'] ?>">
                        <div class="col-5" style="text-align: center;">
                            <!-- Ikon buku menggunakan Font Awesome, ukuran kecil -->
                            <i class="fas fa-book" style="font-size: 20px; color: #555; margin-bottom: 5px;"></i>
                            <p><?php echo $k['category_name'] ?></p>
                        </div>
                    </a>
                <?php }}else{ ?>
                     <p>Kategori tidak ada</p>
                <?php } ?>
            </div>
        </div>
    </div>
    
    <!-- new product -->
    <div class="container">
       <h3>Foto Terbaru</h3>
      
       <?php
           // Mengecek apakah ada parameter 'kat' pada URL
           if(isset($_GET['kat'])){
               $category_id = $_GET['kat'];
               $foto = mysqli_query($conn, "SELECT * FROM tb_image 
                                            LEFT JOIN tb_category ON tb_image.category_id = tb_category.category_id 
                                            WHERE image_status = 1 AND tb_image.category_id = '$category_id' 
                                            ORDER BY image_id DESC 
                                            LIMIT 50");
           } else {
               // Jika tidak ada kategori, tampilkan semua foto
               $foto = mysqli_query($conn, "SELECT * FROM tb_image 
                                            LEFT JOIN tb_category ON tb_image.category_id = tb_category.category_id 
                                            WHERE image_status = 1 
                                            ORDER BY image_id DESC 
                                            LIMIT 50");
           }

           if(mysqli_num_rows($foto) > 0){
               while($p = mysqli_fetch_array($foto)){
                   // Menghitung jumlah like untuk setiap gambar
                   $like_count = mysqli_query($conn, "SELECT COUNT(*) AS total_likes FROM tb_likes WHERE image_id = '".$p['image_id']."'");
                   $like_count = mysqli_fetch_assoc($like_count)['total_likes'];

                   // Menghitung jumlah komentar untuk setiap gambar
                   $comment_count = mysqli_query($conn, "SELECT COUNT(*) AS total_comments FROM tb_comments WHERE image_id = '".$p['image_id']."'");
                   $comment_count = mysqli_fetch_assoc($comment_count)['total_comments'];
       ?>
       <a href="detail-image.php?id=<?php echo $p['image_id'] ?>">
       <div class="col-4">
           <!-- Gambar Foto -->
           <div class="image-container">
               <img src="foto/<?php echo $p['image'] ?>" height="150px" />
           </div>
           <!-- Detail Foto -->
           <div class="image-details">
               <div class="image-info">
                   <!-- Kategori Foto -->
                   <p class="category">Kategori: <?php echo $p['category_name'] ?></p>
                   <p class="admin">Nama User : <?php echo $p['admin_name'] ?></p>
                   <p class="nama"><?php echo $p['date_created'] ?></p>
               </div>
               <div class="image-icons">
                   <span>
                       ❤️ <?php echo $like_count ?>
                   </span>
                   <span>
                       💬 <?php echo $comment_count ?>
                   </span>
               </div>
           </div>
       </div>
       </a>
       <?php }}else{ ?>
           <p>Foto tidak ada</p>
       <?php } ?>
    </div>
    
    <!-- footer -->
    <footer>
        <div class="container">
            <small>Copyright &copy; 2024 - Web Galeri Foto.</small>
        </div>
    </footer>
</body>
</html>
