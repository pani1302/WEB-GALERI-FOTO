<?php
    session_start();
    error_reporting(0);
    include 'db.php';
    
    // Cek apakah ada query ID foto
    $produk = mysqli_query($conn, "SELECT * FROM tb_image WHERE image_id = '".$_GET['id']."' ");
    $p = mysqli_fetch_object($produk);

    // Cek apakah ada form komentar yang dikirim
    if (isset($_POST['submit_comment'])) {
        if (!isset($_SESSION['status_login'])) {
            $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
            echo "<script>alert('Anda harus login terlebih dahulu!'); window.location='login.php';</script>";
        } else {
            $comment = mysqli_real_escape_string($conn, $_POST['comment']);
            
            // Validasi agar komentar tidak kosong dan panjang maksimal
            if (empty($comment)) {
                echo "<script>alert('Komentar tidak boleh kosong!');</script>";
            } elseif (strlen($comment) > 500) {
                echo "<script>alert('Komentar terlalu panjang (maksimal 500 karakter)!');</script>";
            } else {
                $user_id = $_SESSION['id']; // ID pengguna yang login
                $image_id = $p->image_id;

                $insert_comment = mysqli_query($conn, "INSERT INTO tb_comments (image_id, user_id, comment) VALUES ('$image_id', '$user_id', '$comment')");
                if ($insert_comment) {
                    echo "<script>alert('Komentar berhasil ditambahkan!'); window.location='".$_SERVER['REQUEST_URI']."';</script>";
                }
            }
        }
    }

    // Cek apakah ada form like yang dikirim
    if (isset($_POST['like'])) {
        if (!isset($_SESSION['status_login'])) {
            $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
            echo "<script>alert('Anda harus login terlebih dahulu!'); window.location='login.php';</script>";
        } else {
            $user_id = $_SESSION['id']; // ID pengguna yang login
            $image_id = $p->image_id;

            // Cek apakah pengguna sudah memberi like
            $check_like = mysqli_query($conn, "SELECT * FROM tb_likes WHERE image_id = '$image_id' AND user_id = '$user_id'");
            if (mysqli_num_rows($check_like) == 0) {
                $insert_like = mysqli_query($conn, "INSERT INTO tb_likes (image_id, user_id) VALUES ('$image_id', '$user_id')");
                if ($insert_like) {
                    echo "<script>alert('Foto berhasil di-like!'); window.location='".$_SERVER['REQUEST_URI']."';</script>";
                }
            } else {
                $delete_like = mysqli_query($conn, "DELETE FROM tb_likes WHERE image_id = '$image_id' AND user_id = '$user_id'");
                if ($delete_like) {
                    echo "<script>alert('Like telah dibatalkan!'); window.location='".$_SERVER['REQUEST_URI']."';</script>";
                }
            }
        }
    }

    // Hapus komentar
    if (isset($_GET['delete_comment'])) {
        $comment_id = $_GET['delete_comment'];

        // Ambil user_id pemilik komentar
        $comment = mysqli_query($conn, "SELECT user_id FROM tb_comments WHERE comment_id = '$comment_id'");
        $comment_data = mysqli_fetch_assoc($comment);

        if (!$comment_data) {
            echo "<script>alert('Komentar tidak ditemukan!');</script>";
        } elseif (isset($_SESSION['status_login']) && ($_SESSION['id'] == 1 || $_SESSION['id'] == $comment_data['user_id'])) {
            $delete_comment = mysqli_query($conn, "DELETE FROM tb_comments WHERE comment_id = '$comment_id'");
            if ($delete_comment) {
                echo "<script>alert('Komentar berhasil dihapus!'); window.location='".$_SERVER['PHP_SELF']."?id=".$p->image_id."';</script>";
            }
        } else {
            echo "<script>alert('Anda tidak memiliki izin untuk menghapus komentar!');</script>";
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WEB Galeri Foto</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<style>
    /* Mengubah warna teks komentar */
    .comment-text {
        color: #333; /* Warna abu-abu gelap */
    }

    /* Gaya untuk link Hapus agar terlihat dengan jelas */
    .delete-link {
        color: #e74c3c; /* Warna merah */
        text-decoration: none;
    }

    .delete-link:hover {
        color: #c0392b; /* Warna merah gelap saat hover */
    }
</style>
</head>
<body>
    <!-- header -->
    <header>
        <div class="container">
            <h1><a href="dashboard.php">WEB GALERI FOTO</a></h1>
            <ul>
            </ul>
        </div>
    </header>
    
    <!-- product detail -->
    <div class="section">
        <div class="container">
            <h3>Detail Foto</h3>
            <div class="col-2">
                <img src="foto/<?php echo $p->image ?>" width="100%" /> 
            </div>
            <div class="col-2">
                <h3><?php echo $p->image_name ?><br />Kategori : <?php echo $p->category_name ?></h3>
                <h4>Nama User : <?php echo $p->admin_name ?><br />
                Upload Pada Tanggal : <?php echo $p->date_created ?></h4>
                <p>Deskripsi :<br />
                    <?php echo $p->image_description ?>
                </p>

                <!-- Like Button -->
                <form method="POST">
                    <button type="submit" name="like" class="like-btn">
                        👍 <?php
                            $check_like = mysqli_query($conn, "SELECT * FROM tb_likes WHERE image_id = '".$p->image_id."' AND user_id = '".$_SESSION['id']."'");
                            echo (mysqli_num_rows($check_like) == 0) ? "Like" : "Unlike";
                        ?>
                    </button>
                </form>

                <!-- Comments Section -->
                <h4>Komentar</h4>
                <?php if (isset($_SESSION['status_login'])): ?>
                    <form method="POST">
                        <textarea name="comment" placeholder="Tulis komentar..." class="input-control"></textarea>
                        <br>
                        <input type="submit" name="submit_comment" value="Kirim Komentar" class="btn">
                    </form>
                <?php else: ?>
                    <p>Anda harus login untuk memberikan komentar.</p>
                <?php endif; ?>

                <!-- Display Comments -->
                <h5>Daftar Komentar:</h5>
                <?php
                    $comments = mysqli_query($conn, "SELECT * FROM tb_comments LEFT JOIN tb_admin ON tb_comments.user_id = tb_admin.admin_id WHERE tb_comments.image_id = '".$p->image_id."' ORDER BY tb_comments.created_at DESC");
                    while ($comment = mysqli_fetch_array($comments)) {
                        echo "<p class='comment-text'><strong>".$comment['admin_name']."</strong>: ".$comment['comment']." ";
                        if (isset($_SESSION['status_login']) && ($_SESSION['id'] == 1 || $_SESSION['id'] == $comment['user_id'])) { // Admin atau pemilik komentar dapat menghapus komentar
                            echo "<a href='?id=".$p->image_id."&delete_comment=".$comment['comment_id']."' class='delete-link' onclick='return confirm(\"Apakah Anda yakin ingin menghapus komentar ini?\")'>[Hapus]</a>";
                        }
                        echo "</p>";
                    }
                ?>

                <!-- Display Likes -->
                <h5>Orang yang Menyukai:</h5>
                <?php
                    $likes = mysqli_query($conn, "SELECT * FROM tb_likes LEFT JOIN tb_admin ON tb_likes.user_id = tb_admin.admin_id WHERE tb_likes.image_id = '".$p->image_id."'");
                    while ($like = mysqli_fetch_array($likes)) {
                        echo "<p>".$like['admin_name']."</p>";
                    }
                ?>
            </div>
        </div>
    </div>
    
    <!-- footer -->
    <footer>
        <div class="container">
            <small>Copyright &copy; 2024 - Web Galeri Foto.</small>
        </div>
    </footer>
</body>
</html>
