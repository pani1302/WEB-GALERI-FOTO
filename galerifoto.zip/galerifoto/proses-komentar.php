<?php
session_start();
include 'db.php';

if (!isset($_SESSION['status_login'])) {
    echo '<script>alert("Anda harus login untuk memberikan komentar."); window.location="login.php";</script>';
    exit;
}

if (isset($_POST['submit_comment'])) {
    $image_id = $_POST['image_id'];
    $user_id = $_SESSION['id'];
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    // Tambahkan komentar ke database
    mysqli_query($conn, "INSERT INTO comments (user_id, image_id, comment_text, date_comment) 
                         VALUES ('$user_id', '$image_id', '$comment', NOW())");

    echo '<script>window.location="index.php";</script>';
}
?>
